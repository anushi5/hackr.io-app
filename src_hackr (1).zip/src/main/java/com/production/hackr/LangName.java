package com.production.hackr;

public class LangName {
    private String langName;

    public LangName(String langName) {
        this.langName = langName;
    }

    public String getlangName() {
        return this.langName;
    }


    public String getLangName() {
        return langName;
    }
}