package com.production.hackr;

/**
 * Created by Vidushi Sharma on 7/3/2017.
 */

public class AppConfig {
    // Server user login url
    public static String URL_LOGIN = "http://192.168.43.96/android_login_api/login.php";

    // Server user register url
    public static String URL_REGISTER = "http://192.168.43.96/android_login_api/register.php";

    // Server user login url
    public static String URL_LANGUAGE = "http://192.168.43.96/android_login_api/getLanguage.php";

    public static final String _NAME = "name";
    public static final String JSON_ARRAY = "result";
}
